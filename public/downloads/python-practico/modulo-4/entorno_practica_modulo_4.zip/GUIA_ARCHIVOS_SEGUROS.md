# Guía breve de operaciones seguras con archivos

Utiliza esta guía antes de permitir que un programa escriba, copie o mueva información.

## 1. Define el límite

Establece una carpeta base autorizada. Resuelve la base y cada destino antes de comprobar la relación:

```python
base = base.resolve()
destino = destino.resolve()

if not destino.is_relative_to(base):
    raise ValueError("Destino fuera del entorno autorizado.")
```

## 2. Valida antes de modificar

Comprueba primero:

- que el origen exista y sea del tipo esperado;
- que la extensión sea correcta;
- que los encabezados o la estructura sean válidos;
- que todos los destinos estén dentro del entorno;
- que ningún destino exista;
- que los datos puedan prepararse en memoria.

## 3. Calcula las rutas una sola vez

Si el nombre incluye fecha y hora, calcula la marca una vez y reutilízala. El plan mostrado y la operación real deben referirse al mismo destino.

## 4. Simula sin efectos secundarios

Una simulación normal no debe:

- crear carpetas;
- crear archivos vacíos;
- copiar archivos;
- mover información;
- cambiar nombres;
- borrar contenido.

Debe mostrar el origen, el destino y la acción prevista.

## 5. Conserva la fuente

Genera resultados nuevos. Si necesitas una copia, usa un nombre único y evita la sobrescritura. Para este proyecto se utiliza `shutil.copy2()`.

## 6. Utiliza formatos con sus herramientas

- Texto: `open()` o métodos de `Path`, con UTF-8.
- CSV: módulo `csv`, con `newline=""`.
- JSON: módulo `json`, sin convertir todo silenciosamente mediante `default=str`.

## 7. Evita operaciones destructivas automáticas

Este módulo no requiere borrar archivos. No agregues una operación destructiva por comodidad. Si un destino ya existe, detén el proceso e informa cómo resolver el conflicto manualmente.

## 8. Comprueba el resultado

Después de ejecutar:

- abre los resultados;
- valida el JSON;
- compara el original antes y después;
- confirma las cantidades esperadas;
- conserva evidencia de la simulación y la ejecución.
