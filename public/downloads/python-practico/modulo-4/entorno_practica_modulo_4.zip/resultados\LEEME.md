# Carpeta de resultados

El programa guardará aquí los archivos JSON y el reporte de texto durante la ejecución real.

La simulación no debe crear ningún resultado.
