# Lista de comprobación — Proyecto del Módulo 4

## Lectura y rutas

- [ ] Utilicé `Path` en lugar de concatenar separadores manualmente.
- [ ] Abrí todos los archivos mediante `with`.
- [ ] Declaré UTF-8 en texto y JSON.
- [ ] Abrí el CSV con `newline=""`.
- [ ] Verifiqué que la entrada existe, es archivo y termina en `.csv`.
- [ ] Resolví y limité todas las rutas a la carpeta base.

## Procesamiento

- [ ] Validé los cinco encabezados obligatorios.
- [ ] Conservé cada fila original antes de normalizarla.
- [ ] Convertí precio y existencia explícitamente.
- [ ] Detecté códigos repetidos.
- [ ] Acumulé todos los problemas de cada fila.
- [ ] Separé válidos sin cambios, corregidos y rechazados.
- [ ] Obtuve 4 válidos, 2 corregidos y 6 rechazados.

## Resultados

- [ ] `catalogo_limpio.json` contiene 6 productos.
- [ ] `registros_rechazados.json` contiene línea, original y problemas.
- [ ] `reporte.txt` incluye cantidades, categorías, problemas y rutas.
- [ ] El JSON conserva tildes y utiliza indentación.
- [ ] El respaldo fue creado con `copy2()` y un nombre único.

## Seguridad

- [ ] La simulación no crea carpetas, archivos ni copias.
- [ ] Ningún archivo existente se sobrescribe.
- [ ] El CSV original permanece idéntico.
- [ ] No utilicé funciones para borrar archivos o carpetas.
- [ ] El programa se detiene ante un conflicto de integridad.

## Pruebas y entrega

- [ ] Ejecuté y documenté las diez pruebas obligatorias.
- [ ] Incluí capturas de simulación y ejecución.
- [ ] Escribí instrucciones de ejecución en `README.md`.
- [ ] Organicé la entrega con la estructura solicitada.
- [ ] Comprimí todo en un único archivo `.zip`.
