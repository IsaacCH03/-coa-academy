# Carpeta de respaldos

El programa guardará aquí una copia del catálogo original durante la ejecución real.

La simulación no debe crear ningún respaldo.
