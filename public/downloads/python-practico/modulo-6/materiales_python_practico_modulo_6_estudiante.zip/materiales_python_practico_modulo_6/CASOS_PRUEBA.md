# Casos de prueba — COA Toolkit

| # | Caso | Resultado esperado | Estado |
|---:|---|---|:---:|
| 1 | `python main.py --help` | Ayuda completa; código 0 | [ ] |
| 2 | Texto `"  Python   PRÁCTICO  "` | 15 caracteres, 2 palabras, 2 únicas | [ ] |
| 3 | Fecha 2026-08-22 y referencia 2026-08-15 | próxima; faltan 7 días | [ ] |
| 4 | Números 2, 3.5, 5 y 8 | Métricas de control | [ ] |
| 5 | Operación inexistente | Rechazo de argparse | [ ] |
| 6 | Fecha `2026-02-30` | Error esperado; código 2 | [ ] |
| 7 | Valores `texto`, `NaN` e `Infinity` | Rechazo sin traceback al usuario | [ ] |
| 8 | Reporte ya existente | No se sobrescribe | [ ] |
| 9 | Niveles DEBUG y ERROR | Distinto detalle según umbral | [ ] |
| 10 | Importar seis módulos | Solo imprime `OK`; sin efectos | [ ] |
| 11 | Fallo inesperado controlado | Traceback en log; código 1 | [ ] |
| 12 | Texto privado de prueba | No aparece completo en log | [ ] |

## Valores numéricos de control

Para `python main.py numeros 2 3.5 5 8`:

```text
Cantidad: 4
Suma: 18.5
Media: 4.625
Mediana: 4.25
Mínimo: 2.0
Máximo: 8.0
Rango: 6.0
Desviación poblacional: 2.2185 aproximadamente
```

## Registro de cada prueba

Para cada caso documenta:

- comando exacto;
- preparación necesaria;
- resultado esperado;
- resultado observado;
- código de salida cuando corresponda;
- archivo creado o preservado;
- estado final;
- corrección aplicada si falló.
