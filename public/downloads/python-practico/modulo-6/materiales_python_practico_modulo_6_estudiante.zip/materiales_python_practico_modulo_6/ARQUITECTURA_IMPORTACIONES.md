# Arquitectura e importaciones — COA Toolkit

## Flujo de responsabilidades

```text
terminal
   ↓
cli.py ──────→ argumentos
   ↓
main.py ─────→ configura y coordina
   ├─────────→ operaciones.py ───→ errores.py
   ├─────────→ reportes.py
   └─────────→ configuracion.py
```

## Reglas

- `main.py` puede depender de todos los componentes.
- `cli.py` define la interfaz, pero no ejecuta lógica.
- `operaciones.py` no importa `main.py`, no imprime y no configura logging.
- `reportes.py` no decide qué operación se ejecuta.
- `configuracion.py` configura el registro una sola vez.
- `errores.py` no importa módulos de la aplicación.
- Ningún módulo solicita datos mediante `input()`.
- Ningún módulo crea archivos al importarse.

## Prueba de importación

Desde la carpeta del proyecto:

```text
python -c "import cli, configuracion, errores, operaciones, reportes, main; print('OK')"
```

El resultado debe ser únicamente:

```text
OK
```

No deben aparecer preguntas, reportes, eventos ni archivos nuevos.

## Señales de una dependencia circular

- un módulo aparece “parcialmente inicializado”;
- un nombre importado no existe durante la carga;
- `main.py` importa `operaciones.py` y `operaciones.py` importa `main.py`;
- mover una función produce una cadena de importaciones en ambas direcciones.

Corrige la responsabilidad o mueve el elemento compartido a un módulo inferior. No ocultes el problema importando dentro de muchas funciones sin comprender la causa.
