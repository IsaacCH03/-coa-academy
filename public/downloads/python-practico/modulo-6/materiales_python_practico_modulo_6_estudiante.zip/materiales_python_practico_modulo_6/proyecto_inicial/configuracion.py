"""Configuración central del registro técnico de COA Toolkit."""

from __future__ import annotations

import logging
from pathlib import Path


FORMATO_LOG = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"


def configurar_logging(nivel: str, archivo: Path | None = None) -> None:
    """Configura logging una sola vez para la ejecución actual."""
    opciones = {
        "level": getattr(logging, nivel),
        "format": FORMATO_LOG,
    }

    if archivo is not None:
        # TODO: decidir cuándo crear la carpeta padre y cómo informar fallos.
        opciones.update(
            filename=archivo,
            filemode="a",
            encoding="utf-8",
        )

    logging.basicConfig(**opciones)
