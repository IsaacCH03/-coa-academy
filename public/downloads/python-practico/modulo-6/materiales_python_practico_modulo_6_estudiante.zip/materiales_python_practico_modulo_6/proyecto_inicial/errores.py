"""Excepciones del dominio de COA Toolkit."""


class CoaToolkitError(Exception):
    """Error base para situaciones esperables de COA Toolkit."""


class EntradaInvalidaError(CoaToolkitError):
    """Indica que un valor no cumple el contrato de una operación."""


class CombinacionArgumentosError(CoaToolkitError):
    """Indica que varias opciones no pueden utilizarse juntas."""
