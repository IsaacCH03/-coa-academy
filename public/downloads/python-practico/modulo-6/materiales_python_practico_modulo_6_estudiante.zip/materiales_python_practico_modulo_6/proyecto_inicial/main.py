"""Punto de entrada de COA Toolkit."""

from __future__ import annotations

import logging
from collections.abc import Sequence

from cli import crear_parser
from configuracion import configurar_logging
from errores import CoaToolkitError


logger = logging.getLogger(__name__)


def ejecutar(argumentos) -> str:
    """Ejecuta la operación solicitada y devuelve el reporte."""
    # TODO: importar o utilizar las operaciones sin duplicar su lógica.
    # TODO: validar combinaciones de argumentos.
    # TODO: construir el reporte mediante reportes.py.
    del argumentos
    raise NotImplementedError


def main(argv: Sequence[str] | None = None) -> int:
    """Coordina una ejecución y devuelve su código de salida."""
    parser = crear_parser()
    argumentos = parser.parse_args(argv)

    try:
        configurar_logging(argumentos.nivel_log, argumentos.archivo_log)
    except OSError as error:
        print(f"No se pudo configurar el registro: {error}")
        return 3

    logger.info("Aplicación iniciada: operacion=%s", argumentos.operacion)

    try:
        reporte = ejecutar(argumentos)
        # TODO: imprimir o guardar según argumentos.salida.
    except CoaToolkitError as error:
        logger.error("Entrada rechazada: %s", error)
        print(f"Error: {error}")
        return 2
    except OSError as error:
        logger.error("Fallo de archivo: %s", error)
        print(f"Error de archivo: {error}")
        return 3
    except Exception:
        logger.exception("Fallo inesperado")
        print("Ocurrió un error inesperado. Consulta el registro técnico.")
        return 1
    else:
        logger.info("Aplicación finalizada correctamente")
        del reporte
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
