"""Definición de la interfaz de línea de comandos de COA Toolkit."""

from __future__ import annotations

import argparse
from pathlib import Path


OPERACIONES = ("texto", "fecha", "numeros")
NIVELES_LOG = ("DEBUG", "INFO", "WARNING", "ERROR")


def crear_parser() -> argparse.ArgumentParser:
    """Crea y devuelve el analizador de argumentos de COA Toolkit."""
    parser = argparse.ArgumentParser(
        prog="coa-toolkit",
        description=(
            "Normaliza texto, clasifica vencimientos o calcula "
            "estadísticas desde la terminal."
        ),
    )
    parser.add_argument(
        "operacion",
        choices=OPERACIONES,
        help="Operación que se ejecutará.",
    )
    parser.add_argument(
        "valores",
        nargs="+",
        help="Uno o más valores utilizados por la operación.",
    )
    parser.add_argument(
        "--referencia",
        help="Fecha de referencia para 'fecha', en formato AAAA-MM-DD.",
    )
    parser.add_argument(
        "--salida",
        type=Path,
        help="Ruta opcional de un reporte nuevo; no se sobrescribirá.",
    )
    parser.add_argument(
        "--archivo-log",
        type=Path,
        help="Archivo opcional donde se agregarán registros técnicos.",
    )
    parser.add_argument(
        "--nivel-log",
        choices=NIVELES_LOG,
        default="INFO",
        help="Nivel mínimo del registro; predeterminado: INFO.",
    )
    return parser
