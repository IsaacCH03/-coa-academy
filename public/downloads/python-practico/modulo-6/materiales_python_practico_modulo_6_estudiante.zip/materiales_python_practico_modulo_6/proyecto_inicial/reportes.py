"""Presentación y escritura protegida de reportes de COA Toolkit."""

from __future__ import annotations

from pathlib import Path
from typing import Any


def construir_reporte(operacion: str, resultado: dict[str, Any]) -> str:
    """Construye un reporte legible para una operación."""
    # TODO: delegar en una función de formato por operación.
    raise NotImplementedError


def guardar_reporte(ruta: Path, contenido: str) -> None:
    """Crea un reporte UTF-8 sin reemplazar un archivo existente.

    Raises:
        FileExistsError: Si la ruta ya existe.
        OSError: Si el sistema no permite crear el reporte.
    """
    # TODO: crear la carpeta padre y abrir el archivo en modo exclusivo.
    raise NotImplementedError
