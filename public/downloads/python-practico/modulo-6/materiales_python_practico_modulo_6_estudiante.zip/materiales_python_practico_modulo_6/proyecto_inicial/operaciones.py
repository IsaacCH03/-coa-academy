"""Lógica reutilizable de las operaciones de COA Toolkit."""

from __future__ import annotations

from datetime import date
from typing import Any


def analizar_texto(valores: list[str]) -> dict[str, Any]:
    """Normaliza y resume el texto recibido.

    Raises:
        EntradaInvalidaError: Si el resultado normalizado está vacío.
    """
    # TODO: unir, conservar original, normalizar y calcular métricas.
    raise NotImplementedError


def analizar_fecha(
    valores: list[str],
    referencia_texto: str | None,
) -> dict[str, Any]:
    """Calcula y clasifica un vencimiento.

    Raises:
        EntradaInvalidaError: Si la cantidad o el formato son incorrectos.
    """
    # TODO: exigir un valor, convertir fechas y encadenar la causa.
    # TODO: usar date.today() únicamente si no hay referencia explícita.
    del valores, referencia_texto
    raise NotImplementedError


def analizar_numeros(valores: list[str]) -> dict[str, Any]:
    """Convierte números finitos y calcula estadísticas poblacionales.

    Raises:
        EntradaInvalidaError: Si algún valor no es numérico o no es finito.
    """
    # TODO: convertir sin perder la posición del error.
    # TODO: utilizar statistics para las métricas solicitadas.
    raise NotImplementedError
