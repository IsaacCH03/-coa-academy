# Lista de comprobación — Proyecto del Módulo 6

## Excepciones

- [ ] Mis bloques `try` son pequeños.
- [ ] Capturo tipos específicos.
- [ ] No utilizo capturas desnudas.
- [ ] No oculto fallos inesperados.
- [ ] Utilizo una excepción de dominio justificada.
- [ ] Encadeno al menos una causa con `raise ... from`.
- [ ] Devuelvo códigos de salida coherentes.

## Modularidad

- [ ] Conservo los seis módulos solicitados.
- [ ] No dupliqué lógica.
- [ ] No utilizo `import *`.
- [ ] No existen dependencias circulares.
- [ ] Ningún archivo sombrea la biblioteca estándar.
- [ ] Importar los módulos produce únicamente las definiciones.
- [ ] El punto de entrada está protegido.

## Terminal

- [ ] `--help` explica todos los argumentos.
- [ ] `operacion` usa `choices`.
- [ ] `valores` exige uno o más elementos.
- [ ] Implementé las tres operaciones.
- [ ] Probé opciones válidas e inválidas.

## Registros y archivos

- [ ] Configuro logging una sola vez.
- [ ] Utilizo niveles apropiados.
- [ ] No registro textos completos ni datos sensibles.
- [ ] El archivo de log agrega eventos.
- [ ] El archivo de reporte no se sobrescribe.
- [ ] Utilizo UTF-8.

## Documentación y entrega

- [ ] Incluí docstrings en módulos y funciones públicas.
- [ ] Completé el README.
- [ ] Los comandos del README pueden copiarse y ejecutarse.
- [ ] Documenté los doce casos de prueba.
- [ ] Incluí tres reportes, log y evidencias.
- [ ] Excluí `__pycache__`, entornos virtuales y temporales.
- [ ] Comprimí todo en un único ZIP.
