# COA Toolkit

## Propósito

<!-- Explica en dos o tres frases qué problema resuelve la herramienta. -->

## Requisitos

- Python: <!-- Indica la versión mínima comprobada. -->
- Librerías externas: ninguna.

## Estructura

| Archivo | Responsabilidad |
|---|---|
| `main.py` | <!-- Completar --> |
| `cli.py` | <!-- Completar --> |
| `operaciones.py` | <!-- Completar --> |
| `reportes.py` | <!-- Completar --> |
| `configuracion.py` | <!-- Completar --> |
| `errores.py` | <!-- Completar --> |

## Uso

```text
python main.py --help
```

### Operación texto

```text
<!-- Agrega un comando copiable y su salida esperada. -->
```

### Operación fecha

```text
<!-- Agrega un comando con referencia explícita. -->
```

### Operación números

```text
<!-- Agrega un comando con cuatro valores. -->
```

## Opciones

<!-- Explica --referencia, --salida, --archivo-log y --nivel-log. -->

## Códigos de salida

| Código | Significado |
|---:|---|
| 0 | Ejecución correcta |
| 1 | <!-- Completar --> |
| 2 | <!-- Completar --> |
| 3 | <!-- Completar --> |

## Errores esperados

<!-- Incluye ejemplos de fecha inválida, número inválido y destino existente. -->

## Política de archivos

<!-- Explica por qué los reportes no se sobrescriben y los logs se agregan. -->

## Privacidad del registro

<!-- Indica qué contexto se registra y qué datos se excluyen. -->

## Pruebas

<!-- Resume los doce casos y enlaza pruebas.md. -->

## Limitaciones conocidas

<!-- Documenta decisiones conscientes, no errores pendientes ocultos. -->
