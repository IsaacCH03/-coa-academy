# Guía de selección — Fechas, números y aleatoriedad

## ¿Qué representa el dato?

```text
Solo un día del calendario                 → date
Fecha y hora de un evento                  → datetime
Una duración o diferencia                  → timedelta
Medición aproximada                        → float
Dinero o regla decimal exacta              → Decimal
Conteo o cantidad indivisible              → int
Muestra o simulación reproducible          → random.Random(semilla)
Token, contraseña o valor sensible         → secrets
```

## Fechas

- Convierte el texto antes de comparar.
- Declara un contrato de formato.
- Recibe la fecha de referencia en funciones que deban probarse.
- Usa `timedelta` para duraciones exactas en días, segundos o microsegundos.
- No trates 30 días como “un mes” sin una regla del negocio.
- Introduce zonas horarias solo cuando una hora representa un instante real entre regiones.

## `math`

- `ceil()`: capacidad necesaria para cubrir todo.
- `floor()`: cantidad completa que cabe sin superar un límite.
- `isclose()`: comparación aproximada con tolerancias justificadas.
- `sqrt()` y `hypot()`: cálculos geométricos claros.

No utilices `isclose()` para identificadores, conteos o dinero exacto.

## `statistics`

- `mean()`: centro sensible a todos los valores y a los extremos.
- `median()`: centro más resistente a extremos.
- `multimode()`: conserva empates.
- `pstdev()`: población completa.
- `stdev()`: muestra utilizada para estimar una población.

Una colección vacía no tiene una media observada. Informa la ausencia de datos.

## `random`

- `choice()`: una elección.
- `choices()`: varias elecciones con reemplazo y pesos opcionales.
- `sample()`: muestra sin reemplazo.
- `shuffle()`: mezcla una lista en el lugar.
- `Random(semilla)`: generador local reproducible.

La reproducibilidad depende también del orden de los candidatos y de la secuencia de llamadas.

## `Decimal`

```python
from decimal import Decimal, ROUND_HALF_UP

CENTAVO = Decimal("0.01")
valor = Decimal("10.125")
resultado = valor.quantize(CENTAVO, rounding=ROUND_HALF_UP)
```

- Construye desde texto o entero.
- No mezcles con `float`.
- Rechaza `NaN` e infinitos cuando el dominio no los permite.
- Define el modo y el momento del redondeo.
- Formatea solo después de obtener el resultado correcto.
