"""Datos controlados del proyecto del Módulo 5."""

FECHA_REFERENCIA = "2026-08-15"
FORMATO_FECHA = "%Y-%m-%d"
SEMILLA_MUESTRA = 20260815
TAMANIO_MUESTRA = 3
HORAS_POR_SESION = 2.5
TASA_IMPUESTO = "0.13"

TAREAS = [
    {
        "id": "T-001",
        "titulo": "Renovar dominio",
        "fecha_limite": "2026-08-10",
        "duracion_horas": "1.5",
        "prioridad": "alta",
        "costo_estimado": "18.50",
    },
    {
        "id": "T-002",
        "titulo": "Revisar copias de seguridad",
        "fecha_limite": "2026-08-15",
        "duracion_horas": "2",
        "prioridad": "media",
        "costo_estimado": "25.00",
    },
    {
        "id": "T-003",
        "titulo": "Actualizar manual técnico",
        "fecha_limite": "2026-08-18",
        "duracion_horas": "3.5",
        "prioridad": "alta",
        "costo_estimado": "42.75",
    },
    {
        "id": "T-004",
        "titulo": "Ejecutar pruebas integrales",
        "fecha_limite": "2026-08-22",
        "duracion_horas": "5",
        "prioridad": "alta",
        "costo_estimado": "98.30",
    },
    {
        "id": "T-005",
        "titulo": "Capacitar al equipo",
        "fecha_limite": "2026-08-30",
        "duracion_horas": "6",
        "prioridad": "media",
        "costo_estimado": "125.40",
    },
    {
        "id": "T-006",
        "titulo": "Migrar archivos históricos",
        "fecha_limite": "2026-09-14",
        "duracion_horas": "8.25",
        "prioridad": "baja",
        "costo_estimado": "210.99",
    },
    {
        "id": "T-007",
        "titulo": "Cerrar reporte mensual",
        "fecha_limite": "2026-02-30",
        "duracion_horas": "4",
        "prioridad": "media",
        "costo_estimado": "75.00",
    },
    {
        "id": "T-008",
        "titulo": "Corregir factura pendiente",
        "fecha_limite": "2026-08-12",
        "duracion_horas": "dos",
        "prioridad": "alta",
        "costo_estimado": "36.25",
    },
    {
        "id": "T-009",
        "titulo": "Validar presupuesto",
        "fecha_limite": "2026-08-20",
        "duracion_horas": "2.25",
        "prioridad": "media",
        "costo_estimado": "48,90",
    },
    {
        "id": "T-010",
        "titulo": "Preparar demostración",
        "fecha_limite": "18/08/2026",
        "duracion_horas": "3",
        "prioridad": "baja",
        "costo_estimado": "55.00",
    },
    {
        "id": "T-011",
        "titulo": "Confirmar accesos",
        "fecha_limite": "2026-08-16",
        "duracion_horas": "1.25",
        "prioridad": "media",
        "costo_estimado": "15.10",
    },
    {
        "id": "T-012",
        "titulo": "Documentar cierre del proyecto",
        "fecha_limite": "2026-10-01",
        "duracion_horas": "10",
        "prioridad": "baja",
        "costo_estimado": "300.00",
    },
]
