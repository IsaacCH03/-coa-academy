# Casos de prueba — Proyecto del Módulo 5

Registra para cada caso: entrada, resultado esperado, resultado obtenido y estado.

| # | Caso | Resultado esperado | Estado |
|---:|---|---|:---:|
| 1 | Datos originales | 8 aceptadas, 4 rechazadas | [ ] |
| 2 | Fecha igual a referencia | `vence_hoy` | [ ] |
| 3 | Diferencias 1, 7 y 8 | próxima, próxima, vigente | [ ] |
| 4 | `2026-02-30` | Rechazo por fecha | [ ] |
| 5 | Duración `0`, `-1`, `inf`, `texto` | Cuatro rechazos | [ ] |
| 6 | Costo `NaN`, `-1.00`, `48,90` | Tres rechazos | [ ] |
| 7 | Sin tareas válidas | Sin estadísticas inventadas | [ ] |
| 8 | Una tarea válida | `pstdev` igual a 0; muestra controlada | [ ] |
| 9 | Misma semilla y orden | Misma muestra | [ ] |
| 10 | Semilla diferente | La muestra puede cambiar | [ ] |
| 11 | Entrada desordenada | Agenda ordenada por el criterio | [ ] |
| 12 | Inspección de tipos monetarios | Todos son `Decimal` | [ ] |

## Valores de control

```text
Recibidas:                 12
Aceptadas:                  8
Rechazadas:                 4
Vencidas:                   1
Vencen hoy:                 1
Próximas:                   3
Vigentes:                   3
Horas totales:           37.5
Media:                 4.6875
Mediana:                 4.25
Desviación poblacional: 3.0279 aproximadamente
Sesiones:                  18
Modas de prioridad: alta, media
Subtotal:              836.04
Impuesto:              108.69
Total:                 944.73
Muestra: T-002, T-001, T-006
```

## Prueba de reproducibilidad

Para que la muestra de control coincida:

1. conserva el orden original de las ocho tareas aceptadas;
2. crea `random.Random(20260815)`;
3. llama una sola vez a `sample(identificadores, k=3)`;
4. no construyas la población desde un conjunto.

Una semilla no obliga a dos listas de candidatos diferentes a producir la misma muestra.
