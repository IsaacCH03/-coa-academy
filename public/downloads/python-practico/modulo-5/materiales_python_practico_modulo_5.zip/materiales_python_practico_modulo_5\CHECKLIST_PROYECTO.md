# Lista de comprobación — Proyecto del Módulo 5

## Fechas

- [ ] Convierto el texto antes de comparar.
- [ ] Utilizo el contrato `%Y-%m-%d`.
- [ ] Recibo la fecha de referencia de forma explícita.
- [ ] Calculo la diferencia restando objetos temporales.
- [ ] Probé los límites -1, 0, 1, 7 y 8.

## Validación

- [ ] Conservo cada registro original.
- [ ] Acumulo todos los problemas detectables.
- [ ] Valido identificador, título y prioridad.
- [ ] Rechazo fechas imposibles.
- [ ] Rechazo duraciones no finitas o no positivas.
- [ ] Rechazo costos no finitos o negativos.

## Cálculos

- [ ] Utilizo `math.ceil()` para sesiones.
- [ ] Calculo media, mediana, rango y `pstdev()`.
- [ ] Conservo todas las modas con `multimode()`.
- [ ] No invento métricas para una colección vacía.

## Aleatoriedad

- [ ] Utilizo un generador local.
- [ ] Utilizo `sample()` sin reemplazo.
- [ ] Documento la semilla.
- [ ] Conservo el orden de candidatos.
- [ ] Defino qué ocurre si `k` supera la población.

## Dinero

- [ ] Construyo importes desde texto con `Decimal`.
- [ ] No mezclo `Decimal` y `float`.
- [ ] Redondeo con `quantize()` y `ROUND_HALF_UP`.
- [ ] Documento cuándo se redondea.
- [ ] Presento subtotal, impuesto y total con dos decimales.

## Resultados y entrega

- [ ] Obtengo 8 aceptadas y 4 rechazadas.
- [ ] Obtengo 18 sesiones totales.
- [ ] Obtengo la muestra T-002, T-001 y T-006.
- [ ] Obtengo 836.04, 108.69 y 944.73.
- [ ] El reporte contiene los seis bloques obligatorios.
- [ ] Documenté los doce casos de prueba.
- [ ] Incluí `README.md`, evidencias y archivos solicitados.
- [ ] Comprimí la entrega en un único ZIP.
