# Laboratorio de diagnóstico

Resuelve los cinco incidentes por separado. El pseudocódigo puede adaptarse al lenguaje que conoces, pero debes conservar el comportamiento indicado.

Para cada incidente entrega: reproducción, esperado, real, evidencia, dos hipótesis, prueba por hipótesis, causa confirmada, cambio mínimo y regresión.

---

## Incidente 1. Descuento en el límite

Regla: una compra de 100 o más recibe 15 % de descuento.

```text
función calcular_total(subtotal):
    descuento = 0
    si subtotal > 100:
        descuento = subtotal * 0.15
    devolver subtotal - descuento
```

Entrada que debes investigar: `subtotal = 100`.

Casos vecinos: `99.99`, `100` y `100.01`.

---

## Incidente 2. Cantidad con tipo inesperado

Regla: el total es `precio × cantidad` y ambos valores deben ser numéricos válidos.

```text
precio = 12
cantidad = leer_formulario()     // devuelve "3"
total = precio + cantidad
mostrar total
```

Resultado esperado para precio 12 y cantidad 3: `36`.

Antes de corregir, determina si el defecto pertenece a la lectura, validación, conversión u operación. No conviertas silenciosamente cualquier texto.

---

## Incidente 3. Horario final

Regla: una cita puede terminar exactamente a las 18:00, pero no después.

```text
hora_fin = hora_inicio + duracion
si hora_fin >= 18:
    devolver "cita rechazada"
devolver "cita aceptada"
```

Investiga:

- inicio 16, duración 1;
- inicio 17, duración 1;
- inicio 17, duración 2.

---

## Incidente 4. Configuración ausente

Archivo de configuración:

```text
MONEDA=CRC
IMPUESTO=0.13
```

Código:

```text
moneda = configuracion["MONDEA"]
mostrar "Moneda: " + moneda
```

Una propuesta automática sugiere utilizar siempre `"USD"` cuando una clave no exista. Determina si eso corrige la causa o si oculta una configuración inválida.

---

## Incidente 5. Excepción y registro inseguro

```text
función cargar_pedidos(ruta, token):
    intentar:
        contenido = leer(ruta)
        devolver interpretar_json(contenido)
    capturar cualquier_error:
        imprimir "No se pudo leer", ruta, token
        devolver []
```

Investiga por separado:

- archivo inexistente;
- archivo sin permiso;
- JSON inválido;
- error de programación dentro del procesamiento.

Explica por qué devolver una lista vacía puede hacer creer que no existen pedidos y por qué imprimir el token es inseguro.

