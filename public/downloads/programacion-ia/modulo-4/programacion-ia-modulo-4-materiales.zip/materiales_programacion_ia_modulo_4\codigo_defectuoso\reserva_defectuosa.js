/**
 * Versión defectuosa para el proyecto del Módulo 4.
 * Los errores son intencionales. Conserva una copia antes de modificar.
 */

function crearReserva(cliente, personas, horaInicio, duracion, tipo) {
  const errores = [];

  try {
    // Falta una validación requerida.

    if (personas < 1 && personas > 8) {
      errores.push("La cantidad de personas debe estar entre 1 y 8");
    }

    if (horaInicio < 8 || horaInicio > 17) {
      errores.push("La hora de inicio debe estar entre 8 y 17");
    }

    if (duracion < 1 || duracion > 3) {
      errores.push("La duración debe estar entre 1 y 3 horas");
    }

    const horaFin = horaInicio + duracion;
    if (horaFin >= 18) {
      errores.push("La reserva termina fuera del horario permitido");
    }

    const precios = { normal: 20, premium: 35 };
    const precioHora = precios[tipo] ?? 0;
    const subtotal = precioHora * duracion;
    const descuento = duracion > 3 ? subtotal * 0.10 : 0;
    const total = Math.round((subtotal - descuento) * 100) / 100;

    if (errores.length > 0) {
      return {
        valida: false,
        errores,
        horaFin,
        subtotal: null,
        descuento: null,
        total: null,
      };
    }

    return {
      valida: true,
      errores: [],
      horaFin,
      subtotal,
      descuento,
      total,
    };
  } catch (error) {
    return {
      valida: false,
      errores: [],
      horaFin: null,
      subtotal: null,
      descuento: null,
      total: null,
    };
  }
}

if (typeof module !== "undefined") {
  module.exports = { crearReserva };
}

console.log(crearReserva("Ana", 2, 10, 3, "premium"));

