# Registro de hipótesis

| ID | Hipótesis | Evidencia a favor | Evidencia en contra | Predicción | Prueba mínima | Resultado | Estado |
|---|---|---|---|---|---|---|---|
| H-01 |  |  |  |  |  |  | Pendiente |
| H-02 |  |  |  |  |  |  | Pendiente |
| H-03 |  |  |  |  |  |  | Pendiente |

Estados sugeridos: `pendiente`, `confirmada`, `descartada`, `requiere evidencia`.

## Consulta a la IA

- Prompt utilizado:
- Respuesta resumida:
- Hechos identificados:
- Inferencias identificadas:
- Afirmaciones que requieren verificación:
- Fuente consultada:
- Decisión:

## Regla

Una explicación no se marca como confirmada solamente porque coincida con la intuición. Debe producir una predicción y superar una prueba.

