# Plantilla de reproducción

## Identificación

- Incidente:
- Fecha:
- Versión del proyecto:
- Lenguaje y versión:
- Sistema o entorno:

## Estado inicial

- Archivo o componente:
- Configuración relevante:
- Datos ficticios utilizados:

## Pasos exactos

1.
2.
3.

## Entrada

```text

```

## Resultado esperado


## Resultado real


## Frecuencia

- [ ] Siempre
- [ ] Intermitente
- [ ] Una sola vez
- Intentos realizados:
- Fallos observados:

## Evidencia sanitizada

```text

```

## Cambios recientes


## Información todavía desconocida


