# Requisitos del sistema de reservas

## Interfaz principal

Conserva la función o método principal que recibe:

- `cliente`;
- `personas`;
- `hora_inicio`;
- `duracion`;
- `tipo`.

El resultado debe indicar:

- si la reserva es válida;
- lista de errores;
- hora final;
- subtotal;
- descuento;
- total.

Los nombres exactos pueden respetar la convención de cada lenguaje, pero el comportamiento debe ser equivalente.

## Reglas

1. `cliente` debe contener al menos un carácter distinto de espacio.
2. `personas` debe ser un entero entre 1 y 8.
3. `hora_inicio` debe ser un entero entre 8 y 17.
4. `duracion` debe ser un entero entre 1 y 3.
5. `hora_fin = hora_inicio + duracion`.
6. Una hora final igual a 18 es válida; una superior es inválida.
7. `normal` cuesta 20 por hora.
8. `premium` cuesta 35 por hora.
9. Cualquier otro tipo es inválido.
10. Una duración exacta de 3 horas recibe 10 % de descuento.
11. Si existen errores, no debe devolverse un total válido.
12. Cuando sea seguro, se deben acumular los errores de entrada en una sola respuesta.
13. No se deben silenciar errores de programación.
14. Ningún mensaje debe revelar credenciales o datos sensibles.

## Restricciones técnicas

- No reescribir el archivo completo.
- No cambiar la firma pública sin justificación y aprobación.
- No agregar dependencias externas.
- No utilizar una función sugerida sin confirmar su existencia.
- Mantener el código comprensible para el nivel del curso.
- Agregar pruebas de regresión.

