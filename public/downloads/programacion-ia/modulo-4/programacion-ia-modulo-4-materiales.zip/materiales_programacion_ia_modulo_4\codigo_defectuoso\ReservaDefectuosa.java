import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Versión defectuosa para el proyecto del Módulo 4.
 * Los errores son intencionales. Conserva una copia antes de modificar.
 */
public class ReservaDefectuosa {

    public record Resultado(
            boolean valida,
            List<String> errores,
            Integer horaFin,
            Double subtotal,
            Double descuento,
            Double total) {
    }

    public static Resultado crearReserva(
            String cliente,
            int personas,
            int horaInicio,
            int duracion,
            String tipo) {

        List<String> errores = new ArrayList<>();

        try {
            // Falta una validación requerida.

            if (personas < 1 && personas > 8) {
                errores.add("La cantidad de personas debe estar entre 1 y 8");
            }

            if (horaInicio < 8 || horaInicio > 17) {
                errores.add("La hora de inicio debe estar entre 8 y 17");
            }

            if (duracion < 1 || duracion > 3) {
                errores.add("La duración debe estar entre 1 y 3 horas");
            }

            int horaFin = horaInicio + duracion;
            if (horaFin >= 18) {
                errores.add("La reserva termina fuera del horario permitido");
            }

            Map<String, Double> precios = Map.of("normal", 20.0, "premium", 35.0);
            double precioHora = precios.getOrDefault(tipo, 0.0);
            double subtotal = precioHora * duracion;
            double descuento = duracion > 3 ? subtotal * 0.10 : 0.0;
            double total = Math.round((subtotal - descuento) * 100.0) / 100.0;

            if (!errores.isEmpty()) {
                return new Resultado(false, errores, horaFin, null, null, null);
            }

            return new Resultado(true, errores, horaFin, subtotal, descuento, total);
        } catch (Exception error) {
            return new Resultado(false, List.of(), null, null, null, null);
        }
    }

    public static void main(String[] args) {
        System.out.println(crearReserva("Ana", 2, 10, 3, "premium"));
    }
}

