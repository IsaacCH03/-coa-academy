"""Versión defectuosa para el proyecto del Módulo 4.

Los errores son intencionales. Conserva una copia antes de modificar.
"""


def crear_reserva(cliente, personas, hora_inicio, duracion, tipo):
    errores = []

    try:
        # Falta una validación requerida.

        if personas < 1 and personas > 8:
            errores.append("La cantidad de personas debe estar entre 1 y 8")

        if hora_inicio < 8 or hora_inicio > 17:
            errores.append("La hora de inicio debe estar entre 8 y 17")

        if duracion < 1 or duracion > 3:
            errores.append("La duración debe estar entre 1 y 3 horas")

        hora_fin = hora_inicio + duracion
        if hora_fin >= 18:
            errores.append("La reserva termina fuera del horario permitido")

        precios = {"normal": 20, "premium": 35}
        precio_hora = precios.get(tipo, 0)

        subtotal = precio_hora * duracion
        descuento = subtotal * 0.10 if duracion > 3 else 0
        total = round(subtotal - descuento, 2)

        if errores:
            return {
                "valida": False,
                "errores": errores,
                "hora_fin": hora_fin,
                "subtotal": None,
                "descuento": None,
                "total": None,
            }

        return {
            "valida": True,
            "errores": [],
            "hora_fin": hora_fin,
            "subtotal": subtotal,
            "descuento": descuento,
            "total": total,
        }
    except Exception:
        return {
            "valida": False,
            "errores": [],
            "hora_fin": None,
            "subtotal": None,
            "descuento": None,
            "total": None,
        }


if __name__ == "__main__":
    print(crear_reserva("Ana", 2, 10, 3, "premium"))

