#include <cmath>
#include <iostream>
#include <map>
#include <optional>
#include <string>
#include <vector>

// Versión defectuosa para el proyecto del Módulo 4.
// Los errores son intencionales. Conserva una copia antes de modificar.

struct ResultadoReserva {
    bool valida;
    std::vector<std::string> errores;
    std::optional<int> hora_fin;
    std::optional<double> subtotal;
    std::optional<double> descuento;
    std::optional<double> total;
};

ResultadoReserva crear_reserva(
    const std::string& cliente,
    int personas,
    int hora_inicio,
    int duracion,
    const std::string& tipo) {

    std::vector<std::string> errores;

    try {
        // Falta una validación requerida.

        if (personas < 1 && personas > 8) {
            errores.push_back("La cantidad de personas debe estar entre 1 y 8");
        }

        if (hora_inicio < 8 || hora_inicio > 17) {
            errores.push_back("La hora de inicio debe estar entre 8 y 17");
        }

        if (duracion < 1 || duracion > 3) {
            errores.push_back("La duración debe estar entre 1 y 3 horas");
        }

        int hora_fin = hora_inicio + duracion;
        if (hora_fin >= 18) {
            errores.push_back("La reserva termina fuera del horario permitido");
        }

        std::map<std::string, double> precios{{"normal", 20.0}, {"premium", 35.0}};
        double precio_hora = precios.contains(tipo) ? precios.at(tipo) : 0.0;
        double subtotal = precio_hora * duracion;
        double descuento = duracion > 3 ? subtotal * 0.10 : 0.0;
        double total = std::round((subtotal - descuento) * 100.0) / 100.0;

        if (!errores.empty()) {
            return {false, errores, hora_fin, std::nullopt, std::nullopt, std::nullopt};
        }

        return {true, errores, hora_fin, subtotal, descuento, total};
    } catch (...) {
        return {false, {}, std::nullopt, std::nullopt, std::nullopt, std::nullopt};
    }
}

int main() {
    ResultadoReserva resultado = crear_reserva("Ana", 2, 10, 3, "premium");
    std::cout << "Valida: " << std::boolalpha << resultado.valida << '\n';
    return 0;
}

