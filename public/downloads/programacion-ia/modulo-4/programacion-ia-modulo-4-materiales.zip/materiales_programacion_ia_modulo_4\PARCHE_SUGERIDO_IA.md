# Propuesta recibida de una IA

Esta propuesta forma parte del ejercicio de validación. No se ha comprobado que sea correcta.

> Para corregir los errores monetarios, instala o importa la utilidad estándar `Money` de tu lenguaje y reemplaza el cálculo final por `Money.roundCurrency(total, 2)`. Esta función está disponible de forma nativa en Python, JavaScript, Java, C# y C++ y siempre devuelve un número decimal exacto.

## Tu tarea

1. Separa cada afirmación comprobable.
2. Busca `Money.roundCurrency` en la documentación oficial de tu lenguaje.
3. Confirma si `Money` es nativo, externo o inexistente.
4. Confirma firma, versión, retorno y comportamiento decimal.
5. Crea una prueba mínima si encuentras un símbolo equivalente.
6. Decide si aceptas, adaptas o rechazas.
7. Propón una alternativa estándar documentada, solamente si el proyecto la necesita.

No instales un paquete desconocido para hacer que la afirmación parezca correcta.

