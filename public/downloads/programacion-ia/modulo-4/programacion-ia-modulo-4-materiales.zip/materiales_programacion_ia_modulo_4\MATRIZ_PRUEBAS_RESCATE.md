# Matriz de pruebas del rescate

Registra el resultado antes y después de corregir.

| ID | Cliente | Personas | Inicio | Duración | Tipo | Esperado | Antes | Después | Evidencia |
|---|---|---:|---:|---:|---|---|---|---|---|
| RD-01 | Ana | 2 | 8 | 1 | normal | Válida; fin 9; subtotal 20; descuento 0; total 20 |  |  |  |
| RD-02 | Ana | 2 | 17 | 1 | normal | Válida; fin 18; total 20 |  |  |  |
| RD-03 | Ana | 2 | 17 | 2 | normal | Inválida por hora final |  |  |  |
| RD-04 | Ana | 0 | 10 | 1 | normal | Inválida por personas |  |  |  |
| RD-05 | Ana | 9 | 10 | 1 | normal | Inválida por personas |  |  |  |
| RD-06 | espacio en blanco | 2 | 10 | 1 | normal | Inválida por cliente |  |  |  |
| RD-07 | Ana | 2 | 10 | 1 | vip | Inválida por tipo |  |  |  |
| RD-08 | Ana | 2 | 10 | 3 | premium | Válida; subtotal 105; descuento 10.5; total 94.5 |  |  |  |
| RD-09 | Ana | 2 | 10 | 0 | normal | Inválida por duración |  |  |  |
| RD-10 | espacio en blanco | 0 | 7 | 4 | vip | Inválida; acumula errores seguros |  |  |  |
| RD-11 | Definir |  |  |  |  | Caso normal propio |  |  |  |
| RD-12 | Definir |  |  |  |  | Caso límite o inválido propio |  |  |  |

## Resultado por caso

No marques solamente “pasa”. Conserva una salida textual, captura o reporte automático que muestre entrada y resultado.

## Regresión mínima

- [ ] Al menos un caso está documentado fallando antes y pasando después.
- [ ] Los casos que ya funcionaban continúan pasando.
- [ ] Los límites inferiores y superiores están cubiertos.
- [ ] Un tipo desconocido no produce total cero como si fuera válido.
- [ ] Un error interno no se transforma silenciosamente en reserva inválida.

