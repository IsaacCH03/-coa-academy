# Informe de causa raíz

## Resumen

- Incidente:
- Impacto:
- Estado final:

## Reproducción

- Entrada:
- Pasos:
- Esperado:
- Real antes de corregir:

## Evidencia

Incluye únicamente evidencia sanitizada.

```text

```

## Investigación

| Hipótesis | Prueba | Resultado | Conclusión |
|---|---|---|---|
|  |  |  |  |

## Causa raíz


## Corrección aplicada

- Archivos modificados:
- Cambio mínimo:
- Por qué corrige la causa:

## Propuestas de IA

| Propuesta | Aceptada, adaptada o rechazada | Evidencia y razón |
|---|---|---|
|  |  |  |

## Prueba de regresión

- ID:
- Falla antes:
- Pasa después:
- Casos vecinos:

## Verificación final

- Suite ejecutada:
- Resultado:
- Entorno:

## Riesgos pendientes


## Aprendizaje

- Aporte útil de la IA:
- Decisión que dependió de mi razonamiento:
- Qué haría diferente en un próximo incidente:

