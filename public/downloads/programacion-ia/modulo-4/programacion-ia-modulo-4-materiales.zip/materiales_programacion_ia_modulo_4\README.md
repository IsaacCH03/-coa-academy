# Materiales del Módulo 4

## Cómo utilizar este paquete

1. Lee `LABORATORIO_INCIDENTES.md` para completar el mini proyecto.
2. Para el proyecto principal, elige solamente una versión de `codigo_defectuoso`.
3. Lee `REQUISITOS_RESCATE.md` y ejecuta la matriz de pruebas.
4. Conserva el archivo original antes de modificarlo.
5. Utiliza las plantillas para registrar evidencia, hipótesis y causas.
6. Lee `PARCHE_SUGERIDO_IA.md` únicamente cuando llegues a la fase de validación.

Este paquete no contiene soluciones. Los errores forman parte del proyecto.

## Archivos

```text
materiales_programacion_ia_modulo_4/
├── README.md
├── LABORATORIO_INCIDENTES.md
├── REQUISITOS_RESCATE.md
├── MATRIZ_PRUEBAS_RESCATE.md
├── PARCHE_SUGERIDO_IA.md
├── PLANTILLA_REPRODUCCION.md
├── REGISTRO_HIPOTESIS.md
├── INFORME_CAUSA_RAIZ.md
└── codigo_defectuoso/
```

No utilices datos personales, credenciales ni información confidencial.

