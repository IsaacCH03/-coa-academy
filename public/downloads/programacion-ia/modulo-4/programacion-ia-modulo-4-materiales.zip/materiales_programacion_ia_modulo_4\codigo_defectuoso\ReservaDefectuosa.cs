using System;
using System.Collections.Generic;

// Versión defectuosa para el proyecto del Módulo 4.
// Los errores son intencionales. Conserva una copia antes de modificar.

public record ResultadoReserva(
    bool Valida,
    List<string> Errores,
    int? HoraFin,
    decimal? Subtotal,
    decimal? Descuento,
    decimal? Total
);

public static class ReservaDefectuosa
{
    public static ResultadoReserva CrearReserva(
        string cliente,
        int personas,
        int horaInicio,
        int duracion,
        string tipo)
    {
        var errores = new List<string>();

        try
        {
            // Falta una validación requerida.

            if (personas < 1 && personas > 8)
            {
                errores.Add("La cantidad de personas debe estar entre 1 y 8");
            }

            if (horaInicio < 8 || horaInicio > 17)
            {
                errores.Add("La hora de inicio debe estar entre 8 y 17");
            }

            if (duracion < 1 || duracion > 3)
            {
                errores.Add("La duración debe estar entre 1 y 3 horas");
            }

            int horaFin = horaInicio + duracion;
            if (horaFin >= 18)
            {
                errores.Add("La reserva termina fuera del horario permitido");
            }

            var precios = new Dictionary<string, decimal>
            {
                ["normal"] = 20m,
                ["premium"] = 35m
            };

            decimal precioHora = precios.TryGetValue(tipo, out decimal precio) ? precio : 0m;
            decimal subtotal = precioHora * duracion;
            decimal descuento = duracion > 3 ? subtotal * 0.10m : 0m;
            decimal total = Math.Round(subtotal - descuento, 2);

            if (errores.Count > 0)
            {
                return new ResultadoReserva(false, errores, horaFin, null, null, null);
            }

            return new ResultadoReserva(true, errores, horaFin, subtotal, descuento, total);
        }
        catch (Exception)
        {
            return new ResultadoReserva(false, new List<string>(), null, null, null, null);
        }
    }
}

